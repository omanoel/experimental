import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-my2-component',
  templateUrl: 'my2.component.html'
})

export class My2Component {
  @Input() maValeur: any;
 /* @Input() hello: string;
  @Input() something: Function;
  @Output() onSomething = new EventEmitter<string>();
  */
}
